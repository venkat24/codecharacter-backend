#ifndef STATE_ACTOR_FLAG_FWD_H
#define STATE_ACTOR_FLAG_FWD_H

namespace state {

class Flag;

}

#endif
