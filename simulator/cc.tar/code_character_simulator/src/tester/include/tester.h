#ifndef TESTER_H
#define TESTER_H

#include "tester_export.h"

TESTER_EXPORT void print();

#endif
