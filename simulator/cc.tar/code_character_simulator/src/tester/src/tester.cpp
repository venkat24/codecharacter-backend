#include <iostream>
#include "tester.h"
using namespace std;

void print() {
	cout<<"bye\n";
}
