#include "player2.h"

namespace player2 {

void Player2::Update(std::shared_ptr<state::PlayerStateHandler> state) {}

}
