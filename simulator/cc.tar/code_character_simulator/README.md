# Code Character

Simulator for Code Character, a Pragyan '17 event.

---------------------------------------------------

## Design

### Overview

* /src is the source code root.
* Each folder in /src is one project. Each project compiles to one library/executable.
* Each project has an /include folder for headers and /src for definitions.
