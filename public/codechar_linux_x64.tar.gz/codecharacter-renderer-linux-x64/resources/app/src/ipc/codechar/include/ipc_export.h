
#ifndef IPC_EXPORT_H
#define IPC_EXPORT_H

#ifdef IPC_STATIC_DEFINE
#  define IPC_EXPORT
#  define IPC_NO_EXPORT
#else
#  ifndef IPC_EXPORT
#    ifdef ipc_EXPORTS
        /* We are building this library */
#      define IPC_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define IPC_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef IPC_NO_EXPORT
#    define IPC_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef IPC_DEPRECATED
#  define IPC_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef IPC_DEPRECATED_EXPORT
#  define IPC_DEPRECATED_EXPORT IPC_EXPORT IPC_DEPRECATED
#endif

#ifndef IPC_DEPRECATED_NO_EXPORT
#  define IPC_DEPRECATED_NO_EXPORT IPC_NO_EXPORT IPC_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef IPC_NO_DEPRECATED
#    define IPC_NO_DEPRECATED
#  endif
#endif

#endif
