
#ifndef PLAYER2_EXPORT_H
#define PLAYER2_EXPORT_H

#ifdef PLAYER2_STATIC_DEFINE
#  define PLAYER2_EXPORT
#  define PLAYER2_NO_EXPORT
#else
#  ifndef PLAYER2_EXPORT
#    ifdef player2_EXPORTS
        /* We are building this library */
#      define PLAYER2_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PLAYER2_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PLAYER2_NO_EXPORT
#    define PLAYER2_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PLAYER2_DEPRECATED
#  define PLAYER2_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PLAYER2_DEPRECATED_EXPORT
#  define PLAYER2_DEPRECATED_EXPORT PLAYER2_EXPORT PLAYER2_DEPRECATED
#endif

#ifndef PLAYER2_DEPRECATED_NO_EXPORT
#  define PLAYER2_DEPRECATED_NO_EXPORT PLAYER2_NO_EXPORT PLAYER2_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PLAYER2_NO_DEPRECATED
#    define PLAYER2_NO_DEPRECATED
#  endif
#endif

#endif
