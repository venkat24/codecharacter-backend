
#ifndef AI1_EXPORT_H
#define AI1_EXPORT_H

#ifdef AI1_STATIC_DEFINE
#  define AI1_EXPORT
#  define AI1_NO_EXPORT
#else
#  ifndef AI1_EXPORT
#    ifdef ai1_EXPORTS
        /* We are building this library */
#      define AI1_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AI1_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AI1_NO_EXPORT
#    define AI1_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AI1_DEPRECATED
#  define AI1_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AI1_DEPRECATED_EXPORT
#  define AI1_DEPRECATED_EXPORT AI1_EXPORT AI1_DEPRECATED
#endif

#ifndef AI1_DEPRECATED_NO_EXPORT
#  define AI1_DEPRECATED_NO_EXPORT AI1_NO_EXPORT AI1_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AI1_NO_DEPRECATED
#    define AI1_NO_DEPRECATED
#  endif
#endif

#endif
