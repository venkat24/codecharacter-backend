
#ifndef DRIVERS_EXPORT_H
#define DRIVERS_EXPORT_H

#ifdef DRIVERS_STATIC_DEFINE
#  define DRIVERS_EXPORT
#  define DRIVERS_NO_EXPORT
#else
#  ifndef DRIVERS_EXPORT
#    ifdef drivers_EXPORTS
        /* We are building this library */
#      define DRIVERS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define DRIVERS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef DRIVERS_NO_EXPORT
#    define DRIVERS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef DRIVERS_DEPRECATED
#  define DRIVERS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef DRIVERS_DEPRECATED_EXPORT
#  define DRIVERS_DEPRECATED_EXPORT DRIVERS_EXPORT DRIVERS_DEPRECATED
#endif

#ifndef DRIVERS_DEPRECATED_NO_EXPORT
#  define DRIVERS_DEPRECATED_NO_EXPORT DRIVERS_NO_EXPORT DRIVERS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef DRIVERS_NO_DEPRECATED
#    define DRIVERS_NO_DEPRECATED
#  endif
#endif

#endif
