
#ifndef PLAYER1_EXPORT_H
#define PLAYER1_EXPORT_H

#ifdef PLAYER1_STATIC_DEFINE
#  define PLAYER1_EXPORT
#  define PLAYER1_NO_EXPORT
#else
#  ifndef PLAYER1_EXPORT
#    ifdef player1_EXPORTS
        /* We are building this library */
#      define PLAYER1_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PLAYER1_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PLAYER1_NO_EXPORT
#    define PLAYER1_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PLAYER1_DEPRECATED
#  define PLAYER1_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PLAYER1_DEPRECATED_EXPORT
#  define PLAYER1_DEPRECATED_EXPORT PLAYER1_EXPORT PLAYER1_DEPRECATED
#endif

#ifndef PLAYER1_DEPRECATED_NO_EXPORT
#  define PLAYER1_DEPRECATED_NO_EXPORT PLAYER1_NO_EXPORT PLAYER1_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PLAYER1_NO_DEPRECATED
#    define PLAYER1_NO_DEPRECATED
#  endif
#endif

#endif
