
#ifndef PHYSICS_EXPORT_H
#define PHYSICS_EXPORT_H

#ifdef PHYSICS_STATIC_DEFINE
#  define PHYSICS_EXPORT
#  define PHYSICS_NO_EXPORT
#else
#  ifndef PHYSICS_EXPORT
#    ifdef physics_EXPORTS
        /* We are building this library */
#      define PHYSICS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PHYSICS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PHYSICS_NO_EXPORT
#    define PHYSICS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PHYSICS_DEPRECATED
#  define PHYSICS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PHYSICS_DEPRECATED_EXPORT
#  define PHYSICS_DEPRECATED_EXPORT PHYSICS_EXPORT PHYSICS_DEPRECATED
#endif

#ifndef PHYSICS_DEPRECATED_NO_EXPORT
#  define PHYSICS_DEPRECATED_NO_EXPORT PHYSICS_NO_EXPORT PHYSICS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PHYSICS_NO_DEPRECATED
#    define PHYSICS_NO_DEPRECATED
#  endif
#endif

#endif
