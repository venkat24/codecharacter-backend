b=$(pwd | rev | cut -d '/' -f 5- | rev)
grep -r "/home/jhurricane96/renderer/src/ipc/codechar" .. -l | xargs  sed -i "s|/home/jhurricane96/renderer/src/ipc/codechar|$b/resources/app/src/ipc/codechar|g"
mkdir build
cd build
cmake ../ -DCMAKE_INSTALL_PREFIX=../../ipc/codechar -DBUILD_PLAYER1=ON
make install
