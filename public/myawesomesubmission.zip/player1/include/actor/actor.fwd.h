#ifndef STATE_ACTOR_ACTOR_FWD_H
#define STATE_ACTOR_ACTOR_FWD_H

namespace state {

class Actor;

}

#endif
