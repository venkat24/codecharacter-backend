#ifndef STATE_ACTOR_KING_FWD_H
#define STATE_ACTOR_KING_FWD_H

namespace state {

class King;

}

#endif
